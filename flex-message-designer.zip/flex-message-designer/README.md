# 💬 LINE Flex Message Designer

เครื่องมือออกแบบ LINE Flex Message แบบ Visual พร้อม Preview แบบ Real-time

🔗 **Demo:** `https://[your-username].github.io/flex-message-designer`

---

## ✨ ฟีเจอร์

- 🎨 **6 Templates** — Product, Event, Profile, Receipt, ประกาศ, Coupon
- 👁️ **Real-time Preview** — เห็นผลทันทีใน UI จำลอง LINE
- ➕ **เพิ่มปุ่มได้ไม่จำกัด** — ตั้งชื่อ, สไตล์, ลิ้งก์แยกกันทุกปุ่ม
- 🖼️ **Hero หลากหลาย** — Gradient, ลิ้งก์รูปภาพ, Emoji
- 🎨 **ปรับสีได้** — Color picker สีหลัก, สีรอง, สีราคา
- 📋 **Copy JSON** — คัดลอก bubble JSON ไปใช้ใน Flex Simulator
- 📜 **Copy Script** — คัดลอก Node.js script พร้อมใช้กับ Messaging API
- 💬 **ส่งให้เพื่อน** — เปิด Share Target Picker ส่งผ่าน LINE ได้เลย

---

## 🚀 วิธีขึ้น GitHub Pages

### วิธีที่ 1 — ผ่าน GitHub Website (ง่ายที่สุด)

1. ไปที่ [github.com](https://github.com) แล้ว **New repository**
2. ตั้งชื่อ repo เช่น `flex-message-designer`
3. กด **Upload files** แล้วลาก `index.html` ขึ้นไป
4. กด **Commit changes**
5. ไปที่ **Settings → Pages** เลือก Source: `main` branch
6. รอสักครู่ เว็บจะขึ้นที่ `https://[username].github.io/flex-message-designer`

### วิธีที่ 2 — ผ่าน Git CLI

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/[username]/flex-message-designer.git
git push -u origin main
```

จากนั้นเปิด GitHub Pages ใน Settings → Pages

---

## 📁 โครงสร้างไฟล์

```
flex-message-designer/
├── index.html    ← ไฟล์หลัก (Single Page App)
└── README.md     ← ไฟล์นี้
```

---

## 🛠️ Tech Stack

- **Pure HTML/CSS/JS** — ไม่ต้องติดตั้งอะไรเพิ่ม
- **LINE Flex Message v2** — รองรับ bubble format
- **Google Fonts** — Noto Sans Thai, Space Mono

---

## 📄 License

MIT License
